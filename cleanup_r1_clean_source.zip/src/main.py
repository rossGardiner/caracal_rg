import sys
import threading

CANONICAL_CHUNK_DURATION_S = 5.0

from src.CanonicalChunkGrid import CanonicalChunkGrid
chunk_grid = CanonicalChunkGrid(
    chunk_duration_s=CANONICAL_CHUNK_DURATION_S
)

from src.CaracalStreamer import CaracalStreamer
cs = CaracalStreamer(
    "/media/rossg/PortableSSD/BVC Sample Audio"
)

from src.AudioBufferLoader import AudioBufferLoader
abl = AudioBufferLoader(
    chunk_grid=chunk_grid
)

from src.HighPassFilter import HighPassFilter
hps = HighPassFilter()

from src.Resampler import Resampler
rs = Resampler()

from src.EmbeddingsCreator import EmbeddingsCreator
ec = EmbeddingsCreator(
    model_path="assets/perch_v2.onnx"
)

from src.EmbeddingCache import EmbeddingCache
ecache = EmbeddingCache(
    root_directory="cache/embeddings"
)

from src.EmbeddingCacheLoader import EmbeddingCacheLoader
ecl = EmbeddingCacheLoader(
    cache=ecache,
    embeddings_creator=ec,
)

from src.EmbeddingCacheSaver import EmbeddingCacheSaver
ecs = EmbeddingCacheSaver(
    cache=ecache,
    embeddings_creator=ec,
)

from src.SpeedometerLink import SpeedometerLink
sl = SpeedometerLink()

# ==========================================================
# Build the embedding-producing portion of the pipeline first
# ==========================================================
#
# EmbeddingsCreator.get_config_hash() walks upstream through the
# registered PipelineLink.previous chain. The GUI needs that exact hash
# so it can list only cache entries compatible with this pipeline.
# Therefore the upstream chain must exist before ControlWindow is made.
#

cs.register_callback(abl)

abl.register_callback(hps)
hps.register_callback(sl)
sl.register_callback(rs)

rs.register_callback(ecl)
ecl.register_callback(ec)

pipeline_hash = ec.get_config_hash()

from PySide6.QtWidgets import QApplication
from src.QtSignalHandler import QtSignalHandler

app = QApplication(sys.argv)
signal_handler = QtSignalHandler(app)

from src.AudioReader import AudioReader

ar = AudioReader(
    is_caracal=True
)

from src.ControlWindow import ControlWindow

window = ControlWindow(
    audio_packet_source=cs,
    audio_reader=ar,
    chunk_grid=chunk_grid,
    embedding_cache=ecache,
    high_pass_filter=hps,
    resampler=rs,
    embeddings_creator=ec,
    pipeline_hash=pipeline_hash,
    embedding_name=ec.embedding_name,
)

from src.GuiPipelineLink import GuiPipelineLink
gpl = GuiPipelineLink(
    control_window=window
)

# Complete the downstream side of the pipeline after the window exists.
ec.register_callback(ecs)
ecs.register_callback(gpl)

print(
    ecs.get_config_json()
)

window.show()

pipeline_thread = threading.Thread(
    target=cs.stream,
    daemon=True,
)

pipeline_thread.start()

sys.exit(
    app.exec()
)
